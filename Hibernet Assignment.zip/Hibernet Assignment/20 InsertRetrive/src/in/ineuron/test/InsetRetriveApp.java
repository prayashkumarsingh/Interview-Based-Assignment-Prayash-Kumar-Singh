package in.ineuron.test;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import in.ineuron.model.Student;
import in.ineuron.util.HibernateUtil;

public class InsetRetriveApp {
	static int  id = 10;
	public static boolean get() 
	{
		Session session = null;
		
		
		try {
			session = HibernateUtil.getSession();

			if (session != null) {
				Student student = session.load(Student.class, id);
				
				if (student != null) {
					System.out.println("Student id is      :: " + student.getSid());
					
					System.in.read();
					
					System.out.println("STUDENT NAME IS    :: " + student.getSname());
					System.out.println("STUDENT AGE IS     :: " + student.getSage());
					System.out.println("STUDENT ADDRESS IS :: " + student.getSaddress());
				} else
					System.out.println("Record not found for the given id :: " + id);
			}
		} catch (HibernateException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false; 
	
	}

	public static void main(String[] args) throws Exception {

		Session session = null;
		Transaction transaction = null;
		boolean flag = false;
		
		
		try {
			session = HibernateUtil.getSession();

			if (session != null)
				transaction = session.beginTransaction();

			if (transaction != null) {

				Student student = new Student();
				student.setSid(id);
				student.setSname("dh");
				student.setSaddress("C");

				session.persist(student);
				flag = true;
			}

		} catch (HibernateException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (flag) {
				transaction.commit();
				System.out.println("Object saved to database....");
;				System.out.println(get());
			} else {
				transaction.rollback();
				System.out.println("Object not saved to database...");
			}

			HibernateUtil.closeSession(session);
			HibernateUtil.closeSessionFactory();
		}

	}

}
