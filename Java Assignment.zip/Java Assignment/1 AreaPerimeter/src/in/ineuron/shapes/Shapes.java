package in.ineuron.shapes;

import java.util.Scanner;

interface Shapes {
	double area();
	double perimeter();

}
class Circle implements Shapes {

	private double r;

	public Circle(double r) {
		this.r = r;

	}

	@Override
	public double area() {

		return Math.PI * r * r;
	}

	@Override
	public double perimeter() {

		return 2 * Math.PI * r;
	}
}
class Triangle implements Shapes {
	private double a;
	private double b;
	private double c;
	private double h;
	

	public Triangle(double a, double b, double c ,double h) {
		this.h = h;
		this.b = b;
	}

	@Override
	public double area() {

		double A= h * b;
		return A/2;
	}

	@Override
	public double perimeter() {

		return a+b+c;
	}
}


