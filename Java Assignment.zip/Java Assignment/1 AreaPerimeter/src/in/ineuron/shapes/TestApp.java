package in.ineuron.shapes;

import java.util.Scanner;

class TestApp {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Radius of Circle");
		double r = sc.nextDouble();
		Circle C = new Circle(r);
		System.out.println("The Area of Circle is" + C.area());
		System.out.println("The Perimeter of Circle is "+ C.perimeter());
		
		
		
		System.out.println("Enter the lenght of A");
		double a = sc.nextDouble();
		System.out.println("Enter the lenght of B");
		double b = sc.nextDouble();
		System.out.println("Enter the lenght of C");
		double c = sc.nextDouble();
		System.out.println("Enter the lenght of H");
		double h = sc.nextDouble();
		
		Triangle T = new Triangle(a,b,c,h);
		System.out.println("The Area of Triangle is" + T.area());
		System.out.println("The Perimeter of Triangle is "+ T.perimeter());
		

	}
}
