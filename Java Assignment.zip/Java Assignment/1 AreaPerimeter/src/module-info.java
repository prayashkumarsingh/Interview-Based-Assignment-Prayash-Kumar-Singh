/**
 * 
 */
/**
 * @author Prayash
 *
 */
module AreaPerimeter {
}