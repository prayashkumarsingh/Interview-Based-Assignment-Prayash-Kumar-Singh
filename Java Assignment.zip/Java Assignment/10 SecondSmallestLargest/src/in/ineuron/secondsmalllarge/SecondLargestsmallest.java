package in.ineuron.secondsmalllarge;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class SecondLargestsmallest {
    public static void main(String[] args) {
    	List<Integer> numbers = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the total number of elements: ");
        int count = scanner.nextInt();
        
        if (count > 3)
        {
            System.out.println("Enter the elements:");
            for (int i = 0; i < count; i++) {
                numbers.add(scanner.nextInt());
            }
        }
        else
        {
        	System.out.println("Enter the total number of elements more than 3");
        	 System.out.print("Enter the total number of elements: ");
             count = scanner.nextInt();
             
             if (count > 3)
             {
                 System.out.println("Enter the elements:");
                 for (int i = 0; i < count; i++) {
                     numbers.add(scanner.nextInt());
                 }
             }
        }


        Collections.sort(numbers);

        int secondSmallest = numbers.get(1);
        int secondLargest = numbers.get(numbers.size() - 2);

        System.out.println("Second Smallest: " + secondSmallest);
        System.out.println("Second Largest: " + secondLargest);
    }
}

