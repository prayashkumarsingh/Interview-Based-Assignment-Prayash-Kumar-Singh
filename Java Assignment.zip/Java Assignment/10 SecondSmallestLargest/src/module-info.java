/**
 * 
 */
/**
 * @author Prayash
 *
 */
module SecondSmallestLargest {
}