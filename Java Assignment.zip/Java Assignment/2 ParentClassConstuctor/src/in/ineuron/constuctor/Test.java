package in.ineuron.constuctor;

class ParentClass {
	   public ParentClass()
	    {
	        System.out.println("Parent class constuctor called ");
	    }
	 
	    // Parameterized Constructor
	    public ParentClass(int i, int j)
	    {
	        System.out.println("Parent class parameterized constructor called");
	    }

}
class ChildClass extends ParentClass {
	   
    public ChildClass()
    {
        
        super(10, 20);
        System.out.println("Child class constructor called ");
    }
 
   
}
 

public class Test {
    public static void main(String[] args)
    {
        
    	ChildClass obj = new ChildClass();
    }
}

//                    key points of Constructor
//                    *************************


//              A constructor is a special type of method that is used to create an instance of an object.
//              it has same name as class
//              A constructor get called at the time of object creation.

//              Constructor is of 2 types 
//              Default constructor = This is a no argument that is automatically provided  by java
//              Parameterized constructor = This is a constructor that takes one or more arguments.
//                                          You can define parameterized constructor with different 
//                                           parameters as many as needed.
