package in.ineuron.negativeexception;

import java.util.Scanner;

public class NegativeNumberException {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        try {
            System.out.print("Enter an integer: ");
            int n = sc.nextInt();
            
            if (n < 0) {
                throw new IllegalArgumentException("Negative numbers are not allowed.");
            }
            
            System.out.println("The number is: " + n);
        } catch (IllegalArgumentException e) {
            System.out.println("Exception occur: " + e.getMessage());
        } finally {
            sc.close();
        }
    }
}
