/**
 * 
 */
/**
 * @author Prayash
 *
 */
module NegativeException {
}