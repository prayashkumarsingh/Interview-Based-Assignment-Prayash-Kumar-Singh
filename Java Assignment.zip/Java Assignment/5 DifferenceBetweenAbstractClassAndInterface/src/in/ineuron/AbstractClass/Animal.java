package in.ineuron.AbstractClass;

abstract class Animal {
    String name;
    
    public Animal(String name) {
        this.name = name;
    }
    
    public abstract void makeSound();
    
    public void play() {
        System.out.println(name + " is Playing.");
    }
}

class Dog extends Animal {
    public Dog(String name) {
        super(name);
    }
    
    @Override
    public void makeSound() {
        System.out.println(name + " is barking.");
    }
}

class AbstractClassExample {
    public static void main(String[] args) {
        Animal dog = new Dog("Tommy");
        dog.makeSound();
        dog.play();
    }
}
