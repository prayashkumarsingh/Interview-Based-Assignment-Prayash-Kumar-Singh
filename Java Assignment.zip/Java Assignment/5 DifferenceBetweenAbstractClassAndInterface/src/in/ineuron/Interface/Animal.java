package in.ineuron.Interface;


interface Animal {
    void makeSound();
}

class Dog implements Animal {
    @Override
    public void makeSound() {
        System.out.println("The dog is barking.");
    }
}

class Cat implements Animal {
    @Override
    public void makeSound() {
        System.out.println("The cat is meowing.");
    }
}

class Test {
    public static void main(String[] args) {
        Animal dog = new Dog();
        Animal cat = new Cat();
        
        dog.makeSound();
        cat.makeSound();
    }
}

