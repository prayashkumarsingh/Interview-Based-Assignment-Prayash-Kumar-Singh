package in.ineuron.StreamApi;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Stream {
    public static void main(String[] args) {
      
        List<Integer> numbers = new ArrayList<>();
        for (int i = 1; i <= 1000000; i++) {
            numbers.add(i);
        }

        // Sorting the data set
        List<Integer> sortedNumbers = numbers.stream().sorted().collect(Collectors.toList());

        // Filtering the data set
        List<Integer> filteredNumbers = numbers.stream().filter(n -> n % 2 == 0).collect(Collectors.toList());

        
        System.out.println("Sorted numbers: " + sortedNumbers );
       

        System.out.println("Filtered numbers: " + filteredNumbers);
        
    }
}
