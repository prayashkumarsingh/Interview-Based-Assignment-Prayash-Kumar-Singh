/**
 * 
 */
/**
 * @author Prayash
 *
 */
module StreamAPI {
}