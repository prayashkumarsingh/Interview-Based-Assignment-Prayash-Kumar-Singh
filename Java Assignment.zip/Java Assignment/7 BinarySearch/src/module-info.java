/**
 * 
 */
/**
 * @author Prayash
 *
 */
module BinarySearch {
}