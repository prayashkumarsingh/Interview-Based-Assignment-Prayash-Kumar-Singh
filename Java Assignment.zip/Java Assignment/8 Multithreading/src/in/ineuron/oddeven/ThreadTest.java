package in.ineuron.oddeven;

    class EvenNumber implements Runnable {
        @Override
        public void run() {
            for (int i = 2; i <= 10; i += 2) {
                System.out.println("Even Number: " + i);
            }
        }
    }

    class OddNumber implements Runnable {
        @Override
        public void run() {
            for (int i = 1; i <= 9; i += 2) {
                System.out.println("Odd Number: " + i);
            }
        }
    }
    public class ThreadTest {
        public static void main(String[] args) {
            Thread evenThread = new Thread(new EvenNumber());
            Thread oddThread = new Thread(new OddNumber());
            
            evenThread.start();
            
            oddThread.start();
    }
}

