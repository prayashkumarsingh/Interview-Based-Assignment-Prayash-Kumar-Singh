package in.ineuron.producerconsumer;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;



    class Producer implements Runnable {
        private final Queue<Integer> queue;
        private final int maxSize;

        public Producer(Queue<Integer> queue, int maxSize) {
            this.queue = queue;
            this.maxSize = maxSize;
        }

        @Override
        public void run() {
            Random random = new Random();

            while (true) {
                synchronized (queue) {
                    while (queue.size() == maxSize) {
                        try {
                            System.out.println("Queue is full, waiting for consumer...");
                            queue.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }

                    int number = random.nextInt(100);
                    System.out.println("Produced: " + number);
                    queue.offer(number);
                    queue.notifyAll();
                }

                try {
                    Thread.sleep(random.nextInt(1000)); // Pause between producing numbers
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    class Consumer implements Runnable {
        private final Queue<Integer> queue;

        public Consumer(Queue<Integer> queue) {
            this.queue = queue;
        }

        @Override
        public void run() {
            Random random = new Random();
            int sum = 0;

            while (true) {
                synchronized (queue) {
                    while (queue.isEmpty()) {
                        try {
                            System.out.println("Queue is empty, waiting for producer...");
                            queue.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }

                    int number = queue.poll();
                    sum += number;
                    System.out.println("Consumed: " + number);
                    queue.notifyAll();
                }

                try {
                    Thread.sleep(random.nextInt(1000)); // Pause between consuming numbers
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                if (sum > 0) {
                    System.out.println("Sum of consumed numbers: " + sum);
                }
            }
        }
    }
    public class ThreadTest {
        public static void main(String[] args) {
            Queue<Integer> queue = new LinkedList<>();
            int maxSize = 10;

            Thread producerThread = new Thread(new Producer(queue, maxSize));
            Thread consumerThread = new Thread(new Consumer(queue));

            producerThread.start();
            consumerThread.start();
   }
}

