package in.ineuron.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/test")
public class controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		String useremail = request.getParameter("useremail");
		PrintWriter out = response.getWriter();
		
		out.println("<html><head><title>Welcome</title></head>");
		out.println("<body>");
		out.println("<h1 style='color:red; text-align:center;'>WELCOME Mr/Ms/Mrs."+ username +"</h1>");
			out.println("</body>");
			out.println("</html");
		
	}

}
