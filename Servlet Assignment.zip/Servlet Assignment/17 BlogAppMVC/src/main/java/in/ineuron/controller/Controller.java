package in.ineuron.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.ineuron.dto.Blog;
import in.ineuron.service.IBlogService;
import in.ineuron.servicefactory.BlogServiceFactory;

@WebServlet("/controller/*")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	private void doProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		IBlogService blogService = BlogServiceFactory.getBlogService();

		System.out.println("Request URI :: " + request.getRequestURI());
		System.out.println("Path info   :: " + request.getPathInfo());

		if (request.getRequestURI().endsWith("addblog")) {

			String title = request.getParameter("title");
			String description = request.getParameter("description");
			String content = request.getParameter("content");

			Blog blog = new Blog();
			blog.setTitle(title);
			blog.setDescription(description);
			blog.setContent(content);

			String status = blogService.addBlog(blog);
			RequestDispatcher rd = null;

			if (status.equals("success")) {
				request.setAttribute("status", "success");
				rd = request.getRequestDispatcher("../insertresult.jsp");
				rd.forward(request, response);
			} else {
				request.setAttribute("status", "failure");
				rd = request.getRequestDispatcher("../insertresult.jsp");
				rd.forward(request, response);
			}
		}

		if (request.getRequestURI().endsWith("searchblog")) {
			String blogid = request.getParameter("blogid");

			Blog blog = blogService.searchBlog(Integer.parseInt(blogid));
			request.setAttribute("blog", blog);

			RequestDispatcher rd = null;
			rd = request.getRequestDispatcher("../display.jsp");
			rd.forward(request, response);
		}

		if (request.getRequestURI().endsWith("deleteblog")) {
			String blogid = request.getParameter("blogid");
			String status = blogService.deleteBlog(Integer.parseInt(blogid));
			RequestDispatcher rd = null;

			if (status.equals("success")) {
				request.setAttribute("status", "success");
				rd = request.getRequestDispatcher("../deleteresult.jsp");
				rd.forward(request, response);
			} else if (status.equals("failure")) {
				request.setAttribute("status", "failure");
				rd = request.getRequestDispatcher("../deleteresult.jsp");
				rd.forward(request, response);

			} else {
				request.setAttribute("status", "not found");
				rd = request.getRequestDispatcher("../deleteresult.jsp");
				rd.forward(request, response);
			}
		}
		if (request.getRequestURI().endsWith("editblog")) {
			String blogid = request.getParameter("blogid");

			Blog blog = blogService.searchBlog(Integer.parseInt(blogid));
			RequestDispatcher rd = null;
			if (blog != null) {
				request.setAttribute("blog", blog);
				rd = request.getRequestDispatcher("../updateblog.jsp");
				rd.forward(request, response);
			}
		}
		if (request.getRequestURI().endsWith("updateblog")) {
			Integer blogid = Integer.parseInt(request.getParameter("blogid"));
			String title = request.getParameter("title");
			String description = request.getParameter("description");
			String content = request.getParameter("content");

			Blog blog = new Blog();
			blog.setBlogid(blogid);
			blog.setTitle(title);
			blog.setDescription(description);
			blog.setContent(content);

			String status = blogService.updateBlog(blog);
			RequestDispatcher rd = null;

			if (status.equals("success")) {
				rd = request.getRequestDispatcher("../../updatesuccess.html");
				rd.forward(request, response);
			} else {
				rd = request.getRequestDispatcher("../../updatefailure.html");
				rd.forward(request, response);
			}

		}
	}
}

