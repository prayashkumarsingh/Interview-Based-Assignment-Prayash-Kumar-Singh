package in.ineuron.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import in.ineuron.dto.Blog;

import in.ineuron.util.JdbcUtil;


public class BlogDaoImpl implements IBlogDao {

	Connection connection = null;
	PreparedStatement pstmt = null;
	ResultSet resultSet = null;

	@Override
	public String addBlog(Blog blog) {

		String sqlInsertQuery = "insert into blogs(`title`,`description`,`content`)values(?,?,?)";
		try {
			connection = JdbcUtil.getJdbcConnection();

			if (connection != null)
				pstmt = connection.prepareStatement(sqlInsertQuery);

			if (pstmt != null) {

				pstmt.setString(1, blog.getTitle());
				pstmt.setString(2, blog.getDescription());
				pstmt.setString(3, blog.getContent());

				int rowAffected = pstmt.executeUpdate();
				if (rowAffected == 1) {
					return "success";
				}
			}
		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}

		return "failure";
	}

	@Override
	public Blog searchBlog(Integer blogid) {
		String sqlSelectQuery = "select bid,title,description,content from blogs where bid = ?";
		Blog blog = null;

		try {
			connection = JdbcUtil.getJdbcConnection();

			if (connection != null)
				pstmt = connection.prepareStatement(sqlSelectQuery);

			if (pstmt != null)
				pstmt.setInt(1, blogid);

			if (pstmt != null) {
				resultSet = pstmt.executeQuery();
			}

			if (resultSet != null) {

				if (resultSet.next()) {
					blog = new Blog();

					// copy resultSet data to student object
					blog.setBlogid(resultSet.getInt(1));
					blog.setTitle(resultSet.getString(2));
					blog.setDescription(resultSet.getString(3));
					blog.setContent(resultSet.getString(4));

					return blog;
				}

			}

		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}

		return blog;
	}


	@Override
	public String deleteBlog(Integer blogid){
		String sqlDeleteQuery = "delete from blogs where bid = ?";
		try {
			connection = JdbcUtil.getJdbcConnection();

			if (connection != null)
				pstmt = connection.prepareStatement(sqlDeleteQuery);

			if (pstmt != null) {

				pstmt.setInt(1, blogid);

				int rowAffected = pstmt.executeUpdate();
				if (rowAffected == 1) {
					return "success";
				} else {
					return "not found";
				}
			}
		} catch (SQLException | IOException e) {
			e.printStackTrace();
			return "failure";
		}
		return "failure";

	}

	@Override
	public String updateBlog(Blog blog) {
		String sqlUpdateQuery = "update blogs set title=?,description=?,content=? where bid=?";
		try {
			connection = JdbcUtil.getJdbcConnection();

			if (connection != null)
				pstmt = connection.prepareStatement(sqlUpdateQuery);

			if (pstmt != null) {

				pstmt.setString(1, blog.getTitle());
				pstmt.setString(2, blog.getDescription());
				pstmt.setString(3, blog.getContent());
				pstmt.setInt(4, blog.getBlogid());

				int rowAffected = pstmt.executeUpdate();
				if (rowAffected == 1) {
					return "success";
				}
			}
		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}

		return "failure";
	}

}
