package in.ineuron.dao;

import in.ineuron.dto.Blog;

public interface IBlogDao {
	
	public String addBlog(Blog blog);

	public Blog searchBlog(Integer blogid);

	public String updateBlog(Blog blog);

	public String deleteBlog(Integer blogid);

}
