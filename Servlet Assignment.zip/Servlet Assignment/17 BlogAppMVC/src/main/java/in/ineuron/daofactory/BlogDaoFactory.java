package in.ineuron.daofactory;

import in.ineuron.dao.IBlogDao;
import in.ineuron.dao.BlogDaoImpl;
public class BlogDaoFactory {

	private BlogDaoFactory() {}

	private static IBlogDao blogDao = null;

	public static IBlogDao getBlogDao() {
		if (blogDao == null) {
			blogDao = new BlogDaoImpl();
		}
		return blogDao;
	}
}
