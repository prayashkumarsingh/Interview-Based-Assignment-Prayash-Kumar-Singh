package in.ineuron.dto;

import java.io.Serializable;

public class Blog implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private Integer blogid;
	private String title;
	private String description;
	private String content;

	public Integer getBlogid() {
		return blogid;
	}

	public void setBlogid(Integer blogid) {
		this.blogid = blogid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	
	}
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Override
	public String toString() {
		return "Student [blogid=" + blogid + ", title=" + title + ", description=" + description + ", content=" + content + "]";
	}

}
