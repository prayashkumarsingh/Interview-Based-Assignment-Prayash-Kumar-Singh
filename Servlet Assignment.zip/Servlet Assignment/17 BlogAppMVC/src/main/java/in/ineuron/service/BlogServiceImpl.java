package in.ineuron.service;

import in.ineuron.daofactory.BlogDaoFactory;
import in.ineuron.dto.Blog;
import in.ineuron.dao.IBlogDao;



public class BlogServiceImpl implements IBlogService {

	private IBlogDao blogDao;

	@Override
	public String addBlog(Blog blog) {
		blogDao = BlogDaoFactory.getBlogDao();
		return blogDao.addBlog(blog);
	}

	@Override
	public Blog searchBlog(Integer blogid) {
		blogDao = BlogDaoFactory.getBlogDao();
		return blogDao.searchBlog(blogid);
	}

	@Override
	public String updateBlog(Blog blog) {
		blogDao = BlogDaoFactory.getBlogDao();
		return blogDao.updateBlog(blog);
	}

	@Override
	public String deleteBlog(Integer blogid ){
		blogDao = BlogDaoFactory.getBlogDao();
		return blogDao.deleteBlog(blogid);
	}

}
