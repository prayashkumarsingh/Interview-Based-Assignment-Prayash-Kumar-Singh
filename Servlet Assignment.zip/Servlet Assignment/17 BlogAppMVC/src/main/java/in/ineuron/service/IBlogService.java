package in.ineuron.service;

import in.ineuron.dto.Blog;


public interface IBlogService {
	
	
	public String addBlog(Blog blog);

	public Blog searchBlog(Integer blogid);

	public String updateBlog(Blog blog);

	public String deleteBlog(Integer blogid);

}
