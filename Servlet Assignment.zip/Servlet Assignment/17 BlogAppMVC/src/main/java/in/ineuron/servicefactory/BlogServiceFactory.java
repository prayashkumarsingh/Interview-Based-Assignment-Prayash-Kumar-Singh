package in.ineuron.servicefactory;

import in.ineuron.service.IBlogService;
import in.ineuron.service.BlogServiceImpl;



public class BlogServiceFactory {

	
	private BlogServiceFactory() {

	}

	private static IBlogService blogService = null;

	public static IBlogService getBlogService() {
		
		
		if (blogService == null) {
			blogService = new BlogServiceImpl();
		}
		return blogService;
	}

}
