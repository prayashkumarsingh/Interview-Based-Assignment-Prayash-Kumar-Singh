package in.ineuron.main;

import java.io.IOException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import in.ineuron.util.JDBCUtil;


public class SelectApp {

	public static void main(String[] args) {

		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet resultSet = null;
		int id = 1;

		try {
			connection = JDBCUtil.getJdbcConnection();

			String sqlSelectQuery = "select id,name,address,dob from new_table where id=?";
			if (connection != null)
				pstmt = connection.prepareStatement(sqlSelectQuery);

			if (pstmt != null) {
				
				pstmt.setInt(1, id);

				resultSet = pstmt.executeQuery();
			}

			if (resultSet != null) {
				
				if (resultSet.next()) {
					System.out.println("SID\tSNAME\tSDOB");
					int sid = resultSet.getInt(1);
					String sname = resultSet.getString(2);
					String saddress = resultSet.getString(3);
					java.sql.Date sdob = resultSet.getDate(4);
					

					SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
					String strDob = sdf.format(sdob);

					System.out.println(sid + "\t" + sname +"\t" + saddress+ "\t" + strDob);

				} else {
					System.out.println("Record not available for the given id :: " + id);
				}

			}

		} catch (SQLException | IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				JDBCUtil.cleanUp(connection, pstmt, resultSet);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

}
